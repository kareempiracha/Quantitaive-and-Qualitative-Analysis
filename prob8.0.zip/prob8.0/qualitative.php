<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<style>
.DIV {
    width: 100%;
    padding: 10px 0;
    text-align: center;
   
    
}
.card
{
	height:790px;

background-color: #ffffff;
    padding-top: 2%;
    padding-right: 30%;
    padding-left: 10%;
    padding-bottom: 20px;
	margin-top: 10px;
}
</style>
<script>
    var count_a = Number(0);
	var count_b = Number(0);
	var count_c = Number(0);
	function MyFunction() {
	var var_one = document.getElementById("var_one").value;
	var var_two = document.getElementById("var_two").value;
	var var_three = document.getElementById("var_three").value;
    var aa1 = Number(document.getElementById("aa1").value);
    var aa2 = Number(document.getElementById("aa2").value);
    var aa3 = Number(document.getElementById("aa3").value);
    var aa4 = Number(document.getElementById("aa4").value);
    var aa5 = Number(document.getElementById("aa5").value);
    var aa6 = Number(document.getElementById("aa6").value);
    var aa7 = Number(document.getElementById("aa7").value);
    var aa8 = Number(document.getElementById("aa8").value);
    var aa9 = Number(document.getElementById("aa9").value);
    var aa10 = Number(document.getElementById("aa10").value);
    var aa11 = Number(document.getElementById("aa11").value);
	var aa12 = Number(document.getElementById("aa12").value);
    var aa13 = Number(document.getElementById("aa13").value);
	var aa14 = Number(document.getElementById("aa14").value);
	var aa15 = Number(document.getElementById("aa15").value);
	var aa16 = Number(document.getElementById("aa16").value);
	var aa17 = Number(document.getElementById("aa17").value);
	var aa18 = Number(document.getElementById("aa18").value);
	var aa19 = Number(document.getElementById("aa19").value);
	var aa20 = Number(document.getElementById("aa20").value);
	var bb1 = Number(document.getElementById("bb1").value);
    var bb2 = Number(document.getElementById("bb2").value);
    var bb3 = Number(document.getElementById("bb3").value);
    var bb4 = Number(document.getElementById("bb4").value);
    var bb5 = Number(document.getElementById("bb5").value);
    var bb6 = Number(document.getElementById("bb6").value);
    var bb7 = Number(document.getElementById("bb7").value);
    var bb8 = Number(document.getElementById("bb8").value);
    var bb9 = Number(document.getElementById("bb9").value);
    var bb10 = Number(document.getElementById("bb10").value);
    var bb11 = Number(document.getElementById("bb11").value);
	var bb12 = Number(document.getElementById("bb12").value);
    var bb13 = Number(document.getElementById("bb13").value);
	var bb14 = Number(document.getElementById("bb14").value);
	var bb15 = Number(document.getElementById("bb15").value);
	var bb16 = Number(document.getElementById("bb16").value);
	var bb17 = Number(document.getElementById("bb17").value);
	var bb18 = Number(document.getElementById("bb18").value);
	var bb19 = Number(document.getElementById("bb19").value);
	var bb20 = Number(document.getElementById("bb20").value);
	var cc1 =  Number(document.getElementById("cc1").value);
    var cc2 = Number(document.getElementById("cc2").value);
    var cc3 = Number(document.getElementById("cc3").value);
    var cc4 = Number(document.getElementById("cc4").value);
    var cc5 = Number(document.getElementById("cc5").value);
    var cc6 = Number(document.getElementById("cc6").value);
    var cc7 = Number(document.getElementById("cc7").value);
    var cc8 = Number(document.getElementById("cc8").value);
    var cc9 = Number(document.getElementById("cc9").value);
    var cc10 = Number(document.getElementById("cc10").value);
    var cc11 = Number(document.getElementById("cc11").value);
	var cc12 = Number(document.getElementById("cc12").value);
    var cc13 = Number(document.getElementById("cc13").value);
	var cc14 = Number(document.getElementById("cc14").value);
	var cc15 = Number(document.getElementById("cc15").value);
	var cc16 = Number(document.getElementById("cc16").value);
	var cc17 = Number(document.getElementById("cc17").value);
	var cc18 = Number(document.getElementById("cc18").value);
	var cc19 = Number(document.getElementById("cc19").value);
	var cc20 = Number(document.getElementById("cc20").value);
    
	
	if (aa1 != "")
		{
			count_a = count_a + aa1;
		}
	if (aa2 != "")
		{
			count_a = count_a + aa2;
		}
	if (aa3 != "")
		{
			count_a = count_a + aa3;
		}
	if (aa4 != "")
		{
			count_a = count_a + aa4;
		}
	if (aa5 != "")
		{
			count_a = count_a + aa5;
		}
	if (aa6 != "")
		{
			count_a = count_a + aa6;
		}
	if (aa7 != "")
		{
			count_a = count_a + aa7;
		}
	if (aa8 != "")
		{
			count_a = count_a + aa8;
		}
	if (aa9 != "")
		{
			count_a = count_a + aa9;
		}
	if (aa10 != "")
		{
			count_a = count_a + aa10;
		}
	if (aa11 != "")
		{
			count_a = count_a + aa11;
		}
	if (aa12 != "")
		{
			count_a = count_a + aa12;
		}
	if (aa13 != "")
		{
			count_a = count_a + aa13;
		}
	if (aa14 != "")
		{
			count_a = count_a + aa14;
		}
	if (aa15 != "")
		{
			count_a = count_a + aa15;
		}
	if (aa16 != "")
		{
			count_a = count_a + aa16;
		}
	if (aa17 != "")
		{
			count_a = count_a + aa17;
		}
	if (aa18 != "")
		{
			count_a = count_a + aa18;
		}
	if (aa19 != "")
		{
			count_a = count_a + aa19
		}
	if (aa20 != "")
		{
			count_a = count_a + aa20;
		}
	
	if (bb1 != "")
		{
			count_b = count_b + bb1;
		}
	if (bb2 != "")
		{
			count_b = count_b + bb2;
		}
	if (bb3 != "")
		{
			count_b = count_b + bb3;
		}
	if (bb4 != "")
		{
			count_b = count_b + bb4;
		}
	if (bb5 != "")
		{
			count_b = count_b + bb5;
		}
	if (bb6 != "")
		{
			count_b= count_b + bb6;
		}
	if (bb7 != "")
		{
			count_b = count_b + bb7;
		}
	if (bb8 != "")
		{
			count_b = count_b + bb8;
		}
	if (bb9 != "")
		{
			count_b = count_b + bb9;
		}
	if (bb10 != "")
		{
			count_b = count_b + bb10;
		}
	if (bb11 != "")
		{
			count_b = count_b + bb11;
		}
	if (bb12 != "")
		{
			count_b = count_b + bb12;
		}
	if (bb13 != "")
		{
			count_b = count_b + bb13;
		}
	if (bb14 != "")
		{
			count_b = count_b + bb14;
		}
	if (bb15 != "")
		{
			count_b = count_b + bb15;
		}
	if (bb16 != "")
		{
			count_b = count_b + bb16;
		}
	if (bb17 != "")
		{
			count_b = count_b + bb17;
		}
	if (bb18 != "")
		{
			count_b = count_b + bb18;
		}
	if (bb19 != "")
		{
			count_b = count_b + bb19
		}
	if (bb20 != "")
		{
			count_b = count_b + bb20;
		}
	if (cc1 != "")
		{
			count_c = count_c + cc1;
		}
	if (cc2 != "")
		{
			count_c = count_c + cc2;
		}
	if (cc3 != "")
		{
			count_c = count_c + cc3;
		}
	if (cc4 != "")
		{
			count_c = count_c + cc4;
		}
	if (cc5 != "")
		{
			count_c = count_c + cc5;
		}
	if (cc6 != "")
		{
			count_c = count_c + cc6;
		}
	if (cc7 != "")
		{
			count_c = count_c + cc7;
		}
	if (cc8 != "")
		{
			count_c = count_c + cc8;
		}
	if (cc9 != "")
		{
			count_c = count_c + cc9;
		}
	if (cc10 != "")
		{
			count_c = count_c + cc10;
		}
	if (cc11 != "")
		{
			count_c = count_c + cc11;
		}
	if (cc12 != "")
		{
			count_c = count_c + cc12;
		}
	if (cc13 != "")
		{
			count_c = count_c + cc13;
		}
	if (cc14 != "")
		{
			count_c = count_c + cc14;
		}
	if (cc15 != "")
		{
			count_c = count_c + cc15;
		}
	if (cc16 != "")
		{
			count_c = count_c + cc16;
		}
	if (cc17 != "")
		{
			count_c = count_c + cc17;
		}
	if (cc18 != "")
		{
			count_c = count_c + cc18;
		}
	if (cc19 != "")
		{
			count_c = count_c + cc19
		}
	if (cc20 != "")
		{
			count_c = count_c + cc20;
		}

	 var mode = Math.max(count_a, count_b,count_c);
	 
	 var variable = "0";
	
	{
		if (var_one == "")
		 {
			 var_one = "Variable One";
		 }
		 if (var_three == "")
		 {
			 var_three = "Variable Three";
		 }
	    if (var_two == "")
		 {
			 var_two = "Variable Two";
		 }
	 }

	
	 
	 {
	if (mode == count_a)
		 {
			 variable = var_one;
		 }
	if (mode == count_b)
		 {
			 variable = var_two;
		
		 }
	if (mode == count_c)
		 {
			 variable = var_three;
		 }
	 }

 document.getElementById("mode").innerHTML = mode;
 document.getElementById("variable").innerHTML = variable;
}

</script>
</head>
<body>

<div class="nav">
<img src="bingoo.jpg" style=" height: 55px;  border-top:3px solid #171974; border-bottom:1px solid #171974;border-left:30px solid #171974; 
    width: 75px;">
                <a class="button" href="help.php" style="float:right; border-radius: 8px;">HELP</a>
                <a class="button" href="about.php" style="float:right; border-radius: 8px;">ABOUT US</a>
                <a class="button" href="menu.php" style=" float:right; border-radius: 8px;" >MENU</a>
            </div>
                
            
                <div class="row">

                    <div class="column12">
					<h1>Qualitative</h1>
                            <p>Insert Name Of Variable: </p>
                            <br>
                           <input type="text" id="name_variable" name="name_variable" >
                           
							<br>
<form>
<br>
Variable 1:
<input type="text" id="var_one" >
<p>Insert Values: </p>
<div class="DIV" id="DIV1">
<input name="aa1" id="aa1" type="number">
<input name="aa2" id="aa2" type="number">
<input name="aa3" id="aa3" type="number">
<input name="aa4" id="aa4" type="number">
<input name="aa5" id="aa5" type="number">
<input name="aa6" id="aa6" type="number">
<input name="aa7" id="aa7" type="number">
<input name="aa8" id="aa8" type="number">
<input name="aa9" id="aa9" type="number">
<input name="aa10" id="aa10" type="number">
<input name="aa11" id="aa11" type="number">
<input name="aa12" id="aa12" type="number">
<input name="aa13" id="aa13" type="number">
<input name="aa14" id="aa14" type="number">
<input name="aa15" id="aa15" type="number">
<input name="aa16" id="aa16" type="number">
<input name="aa17" id="aa17" type="number">
<input name="aa18" id="aa18" type="number">
<input name="aa19" id="aa19" type="number">
<input name="aa20" id="aa20" type="number">
<br>
</div>

<br>
Variable 2:
<input type="text" id="var_two" >
<p>Insert Values: </p>
<div class="DIV" id="DIV1">
<input name="bb1" id="bb1" type="number">
<input name="bb2" id="bb2" type="number">
<input name="bb3" id="bb3" type="number">
<input name="bb4" id="bb4" type="number">
<input name="bb5" id="bb5" type="number">
<input name="bb6" id="bb6" type="number">
<input name="bb7" id="bb7" type="number">
<input name="bb8" id="bb8" type="number">
<input name="bb9" id="bb9" type="number">
<input name="bb10" id="bb10" type="number">
<input name="bb11" id="bb11" type="number">
<input name="bb12" id="bb12" type="number">
<input name="bb13" id="bb13" type="number">
<input name="bb14" id="bb14" type="number">
<input name="bb15" id="bb15" type="number">
<input name="bb16" id="bb16" type="number">
<input name="bb17" id="bb17" type="number">
<input name="bb18" id="bb18" type="number">
<input name="bb19" id="bb19" type="number">
<input name="bb20" id="bb20" type="number">
<br>
</div>
<br>
Variable 3:
<input type="text" id="var_three" >
<p>Insert Values: </p>
<div class="DIV" id="DIV1">
<input name="cc1" id="cc1" type="number">
<input name="cc2" id="cc2" type="number">
<input name="cc3" id="cc3" type="number">
<input name="cc4" id="cc4" type="number">
<input name="cc5" id="cc5" type="number">
<input name="cc6" id="cc6" type="number">
<input name="cc7" id="cc7" type="number">
<input name="cc8" id="cc8" type="number">
<input name="cc9" id="cc9" type="number">
<input name="cc10" id="cc10" type="number">
<input name="cc11" id="cc11" type="number">
<input name="cc12" id="cc12" type="number">
<input name="cc13" id="cc13" type="number">
<input name="cc14" id="cc14" type="number">
<input name="cc15" id="cc15" type="number">
<input name="cc16" id="cc16" type="number">
<input name="cc17" id="cc17" type="number">
<input name="cc18" id="cc18" type="number">
<input name="cc19" id="cc19" type="number">
<input name="cc20" id="cc20" type="number">
<br>
</div>

</form>

<button class="button" style ="text-align:center;border-radius: 8px;border: 5px solid #171974; padding: 5px 10px; font-size: 20px;" type=button name=more id=more onclick=" MyFunction()">Calculate</button>
</div>
<div class="column123">
<br><br>
<div style ="text-align:center">
<p>Mode:<p id="variable">--</p></p>
<p>Totality:<p id="mode">0.00</p></p>
</div>
</div>
<button class="button" style ="text-align:center;border-radius: 8px;border: 5px solid #171974; padding: 5px 10px; font-size: 20px;" type=button name=more id=more onclick=" graph()">Graph</button>

<!-- yes karao start -->

<div class="column123">
<br><br>
<div style ="text-align:center">
<div id="chartContainer" style="height: 300px; width: 100%;"></div>
<div id="chartContainer1" style="height: 300px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script>
function graph(){

var var_one = document.getElementById("var_one").value;
var var_two = document.getElementById("var_two").value;
var var_three = document.getElementById("var_three").value;

{
		if (var_one == "")
		 {
			 var_one = "Variable One";
		 }
		 if (var_three == "")
		 {
			 var_three = "Variable Three";
		 }
	    if (var_two == "")
		 {
			 var_two = "Variable Two";
		 }
}
//pie chart
var chart = new CanvasJS.Chart("chartContainer", {
	exportEnabled: true,
	animationEnabled: true,
	title:{
		text: "Student data 2018 "
	},
	legend:{
		cursor: "pointer",
		itemclick: explodePie
	},
	data: [{
		type: "pie",
		showInLegend: true,
		toolTipContent: "{name}: <strong>{y}%</strong>",
		indexLabel: "{name} - {y}%",
		dataPoints: [
			{ y: count_a, name: var_one, exploded: true ,color: 'red'},
			{ y: count_b, name: var_two, exploded: true ,color: 'purple'},
			{ y: count_c, name: var_three, exploded: true ,color: 'green'},
					]
	}]
});
chart.render();
function explodePie (e) {
	if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
	} else {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
	}
	e.chart.render();
}
//bar chart	

var chart = new CanvasJS.Chart("chartContainer1", {
	animationEnabled: true,
	theme: "light1", // "light1", "light2", "dark1", "dark2"
	axisY: {
		title: "Frequency"
	},
	data: [/*{        
		type: "column",  
		showInLegend: true, 
		legendMarkerColor: "grey",
		legendText: "Males",
		dataPoints: [      
			{ label: "1", y: 14 },
			{ label: "2", y: 20 },
			{ label: "3", y: 21 },
			{ label: "4", y: 16 },
			{ label: "5", y: 11 },
			{ label: "6", y: 29 },
			{ label: "7", y: 31 },
		]	
	},*/
	{
		type: "column",	
		name: "",
		legendText: "",
		//axisYType: "secondary",
		showInLegend: true,
		dataPoints:[
			
			{ label: var_one, y: count_a },
			{ label: var_two, y: count_b },
			{ label: var_three, y: count_c },
		]
	}]
});
chart.render();




}
</script>

</div>
</div>

<!-- yes Karao  end -->




</div>
           
            <div class="footer">        
                <p>bingoo</p>  
            </div>
</body>
</html>
