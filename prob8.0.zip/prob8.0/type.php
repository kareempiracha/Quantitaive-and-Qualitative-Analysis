<HTML>
    
        <head>
           <title>Creative Hand</title>
            <link rel="stylesheet" type="text/css" href="style.css">
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
        
        </head>
        
        <body>        
            <div class="nav">
            <img src="bingoo.jpg" style=" height: 55px;  border-top:3px solid #171974; border-bottom:1px solid #171974;border-left:30px solid #171974; 
    width: 75px;">
                <a class="button" href="help.php" style="float:right; border-radius: 8px;">HELP</a>
                <a class="button" href="about.php" style="float:right; border-radius: 8px;">ABOUT US</a>
                <a class="button" href="menu.php" style=" float:right; border-radius: 8px;" >MENU</a>
            </div>
                
           
                <div class="row">
                    <div class="card">
                    <h1>Type</h1>
                            <p>Please Select Type Of Your Data</p>
                             
                    </div>
                    <div class="card1">
                    <a class="button" href="qualitative.php"  style ="border-radius: 8px;border: 5px solid #171974; padding: 30px 100px; font-size: 35px;">Qualitative</a>
        <a class="button" href="quantitative.php"  style ="border-radius: 8px;border: 5px solid #171974; padding: 30px 100px; font-size: 35px;">Quantitative</a>
                </div>
</div>
           
            
            <div class="footer">        
                <p>bingoo</p>  
            </div>
                
        </body>
        </HTML>