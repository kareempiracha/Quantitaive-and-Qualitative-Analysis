<HTML>
    
        <head>
           <title>Creative Hand</title>
            <link rel="stylesheet" type="text/css" href="style.css">
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
        
        </head>
        
        <body>        
            <div class="nav">
            <img src="bingoo.jpg" style=" height: 55px;  border-top:3px solid #171974; border-bottom:1px solid #171974;border-left:30px solid #171974; 
    width: 75px;">
                <a class="button" href="help.php" style="float:right; border-radius: 8px;">HELP</a>
                <a class="button" href="about.php" style="float:right; border-radius: 8px;">ABOUT US</a>
                <a class="button" href="menu.php" style=" float:right; border-radius: 8px;" >MENU</a>
            </div>
                
                            <div class="row">
                    <div class="card">
                        <h1>Help</h1>
                            <p>Winning the World Cup was very special because it meant so much to so many. One thing about our country that is constant is cricket. The smile it brought to people's faces was the thing I shall always remember. It reminded me, reminded all of us, of our importance to the lives of the Indian people less lucky than we are.</p>
                            
                    </div>
                    <div class="card1">
                    <a class="button" href="menu.php" style ="border-radius: 8px;border: 5px solid #171974; padding: 30px 100px; font-size: 35px;" >START</a>
                </div>
</div>
            
            
            <div class="footer">        
                <p>bingoo</p>  
            </div>
                
        </body>
        </HTML>