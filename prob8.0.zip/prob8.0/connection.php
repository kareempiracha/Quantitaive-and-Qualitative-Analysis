<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>

<?php


$connention=@mysql_connect("localhost","root","") or die(mysql_error()) ;

$db=@mysql_select_db("fast") or die(mysql_error());


?>
</body>
</html>