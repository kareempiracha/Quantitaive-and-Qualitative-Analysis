<!DOCTYPE HTML>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
<style>
.DIV {
    width: 100%;
    padding: 10px 0;
    text-align: center;
   
    
}
.card
{
	height:790px;

background-color: #ffffff;
    padding-top: 2%;
    padding-right: 30%;
    padding-left: 10%;
    padding-bottom: 20px;
	margin-top: 10px;
}
</style>
<script>
var arr = new Array(40);
function MyFunction() {
	
    var a1 = document.getElementById("a1").value;
    var a2 = document.getElementById("a2").value;
    var a3 = document.getElementById("a3").value;
    var a4 = document.getElementById("a4").value;
    var a5 = document.getElementById("a5").value;
    var b1 = document.getElementById("b1").value;
    var b2 = document.getElementById("b2").value;
    var b3 = document.getElementById("b3").value;
    var b4 = document.getElementById("b4").value;
    var b5 = document.getElementById("b5").value;
    var c1 = document.getElementById("c1").value;
    var c2 = document.getElementById("c2").value;
    var c3 = document.getElementById("c3").value;
    var c4 = document.getElementById("c4").value;
    var c5 = document.getElementById("c5").value;
    var d1 = document.getElementById("d1").value;
    var d2 = document.getElementById("d2").value;
    var d3 = document.getElementById("d3").value;
    var d4 = document.getElementById("d4").value;
    var d5 = document.getElementById("d5").value;
    var e1 = document.getElementById("e1").value;
    var e2 = document.getElementById("e2").value;
    var e3 = document.getElementById("e3").value;
    var e4 = document.getElementById("e4").value;
    var e5 = document.getElementById("e5").value;
    var f1 = document.getElementById("f1").value;
    var f2 = document.getElementById("f2").value;
    var f3 = document.getElementById("f3").value;
    var f4 = document.getElementById("f4").value;
    var f5 = document.getElementById("f5").value;
    var g1 = document.getElementById("g1").value;
    var g2 = document.getElementById("g2").value;
    var g3 = document.getElementById("g3").value;
    var g4 = document.getElementById("g4").value;
    var g5 = document.getElementById("g5").value;
    var h1 = document.getElementById("h1").value;
    var h2 = document.getElementById("h2").value;
    var h3 = document.getElementById("h3").value;
    var h4 = document.getElementById("h4").value;
    var h5 = document.getElementById("h5").value;
	
	var count=0;
	
	
	if (a1 != "")
		{
			arr[count] = Number(a1);
            count++;
		}

    if  (a2 != "") {
		arr[count] = Number(a2);
        count++;
    } 
    if(a3 != "") {
		arr[count] = Number(a3);
        count++;
    } 
    if(a4 != "") {
		arr[count] = Number(a4);
        count++;
    } 
    if(a5 != "") {
		arr[count] = Number(a5);
        count++;
    } 
    if(b1 != "") {
		arr[count] = Number(b1);
        count++;
    } 
    if(b2 != "") {
		arr[count] = Number(b2);
        count++;
    }  
    if(b3 != "") {
		arr[count] = Number(b3);
        count++;
    }  
    if(b4 != "") {
		arr[count] = Number(b4);
        count++;
    } 
    if(b5 != "") {
		arr[count] = Number(b5);
        count++;
    }
    if (c1 != "") {
		arr[count] = Number(c1);
       count++;
    } 
    if(c2 != "") {
		arr[count] = Number(c2);
        count++;
    } 
    if(c3 != "") {
		arr[count] = Number(c3);
        count++;
    } 
    if(c4 != "") {
		arr[count] = Number(c4);
        count++;
    } 
    if(c5 != "") {
		arr[count] = Number(c5);
        count++;
    } 
    if(d1 != "") {
		arr[count] = Number(d1) ;
        count++;
    } 
    if(d2 != "") {
		arr[count] = Number(d2);
        count++;
    }  
    if(d3 != "") {
		arr[count] = Number(d3);
        count++;
    }  
    if(d4 != "") {
		arr[count] = Number(d4);
        count++;
    } 
    if(d5 != "") {
		arr[count] = Number(d5);
        count++;
    }
    if(e1 != "") {
		arr[count] = Number(e1);
        count++;
    }
	if(e2 != "") {
		arr[count] = Number(e2);
        count++;
    }
	if(e3 != "") {
		arr[count] = Number(e3);
        count++;
    }
	if(e4 != "") {
		arr[count] = Number(e4);
        count++;
    }
	if(e5 != "") {
		arr[count] = Number(e5);
        count++;
    }
	if(f1 != "") {
		arr[count] = Number(f1);
        count++;
    }
	if(f2 != "") {
		arr[count] = Number(f2);
        count++;
    }
	
	if(f3 != "") {
		arr[count] = Number(f3);
        count++;
    }
	
	if(f4 != "") {
		arr[count] = Number(f4);
        count++;
    }
	
	if(f5 != "") {
		arr[count] = Number(f5);
        count++;
    }
	
	if(g1 != "") {
		arr[count] = Number(g1);
        count++;
    }
	
	if(g2 != "") {
		arr[count] = Number(g2);
        count++;
    }
	
	if(g3 != "") {
		arr[count] = Number(g3);
        count++;
    }
	
	if(g4 != "") {
		arr[count] = Number(g4);
        count++;
    }
	
	if(g5 != "") {
		arr[count] = Number(g5);
        count++;
    }
	
	if(h1 != "") {
		arr[count] = Number(h1);
        count++;
    }
	
	if(h2 != "") {
		arr[count] = Number(h2);
        count++;
    }
	
	if(h3 != "") {
		arr[count] = Number(h3);
        count++;
    }
	
	if(h4 != "") {
		arr[count] = Number(h4);
        count++;
    }
	
	if(h5 != "") {
		arr[count] = Number(h5);
        count++;
    }

    var sum =  Number(a1) + Number(a2) + Number(a3) + Number(a4) + Number(a5) + Number(b1) + Number(b2) + Number(b3) + Number(b4) + Number(b5) + Number(c1) + Number(c2) + Number(c3) + Number(c4) + Number(c5)
    + Number(d1) + Number(d2) + Number(d3) + Number(d4) + Number(d5) + Number(e1) + Number(e2) + Number(e3) + Number(e4) + Number(e5) + Number(f1) + Number(f2) + Number(f3) + Number(f4) + Number(f5)
    + Number(g1) + Number(g2) + Number(g3) + Number(g4) + Number(g5) + Number(h1) + Number(h2) + Number(h3) + Number(h4) + Number(h5);
	
	//mean 
	
	var mean = sum / count;
	
	// Median
	
	var median=0;
	
	arr.sort(function(a, b){return a - b});
	
	if (count % 2 == 0)  //even values
		{
		    median = Number(arr[(count / 2)])+ Number(arr[((count / 2)+1)]);
			median = median/2;
			
		}
	
	if (count % 2 == 1)  //odd values
		{
		    median = Number(arr[(((count-1)/2))]);
			
		}
	
	//Frequency
	
	var max = arr.reduce(function(a, b) {
    return Math.max(a, b);});
	var min = arr.reduce(function(a, b) {
    return Math.min(a, b);});
	
	var temp = Number((max-min)/6);
	var h1=0;
	var h2=0;
	var h3=0;
	var h4=0;
	var h5=0;
	
	var class1 = min;
    var class2 = min + temp;
	var class3 = min + temp*2;
	var class4 = min + temp*3;
	var class5 = min + temp*4;
	var class6 = min + temp*5;

	
	for(var i =0; i<count;i++)
			{	
				
				if (arr[i] < class2 && arr[i] > min)
					{
						h1++; 
					}
				if (arr[i] > class2 && arr[i] < class3)
					{
						h2++;
					}
				if (arr[i] > class3 && arr[i] < class4)
					{
						h3++;
					}
				if (arr[i] > class4 && arr[i] < class5)
					{
						h4++;
					}
				if (arr[i] > class5 && arr[i] < class6)
					{
						h5++;
					}
				
			}
     
	
	//Variance 
	
	var variance = 0;
	
	if (a1 + sum != sum )
		{
			variance = variance + ((a1 - mean)*(a1 - mean));
		}
	if (a2 + sum != sum )
		{
			variance = variance + ((a2 - mean)*(a2 - mean));
		}
	
	if (a3 + sum != sum )
		{
			variance = variance + ((a3 - mean)*(a3 - mean));
		}
	
	if (a4 + sum != sum )
		{
			variance = variance + ((a4 - mean)*(a4 - mean));
		}
	
	if (a5 + sum != sum )
		{
			variance = variance + ((a5 - mean)*(a5 - mean));
		}
	
	if (b1 + sum != sum )
		{
			variance = variance + ((b1 - mean)*(b1 - mean));
		}
	
	if (b2 + sum != sum )
		{
			variance = variance + ((b2 - mean)*(b2 - mean));
		}
	
	if (b3 + sum != sum )
		{
			variance = variance + ((b3 - mean)*(b3 - mean));
		}
	
	if (b4 + sum != sum )
		{
			variance = variance + ((b4 - mean)*(b4 - mean));
		}
	
	if (b5 + sum != sum )
		{
			variance = variance + ((b5 - mean)*(b5 - mean));
		}
	
	if (c1 + sum != sum )
		{
			variance = variance + ((c1 - mean)*(c1 - mean));
		}
	
	if (c2 + sum != sum )
		{
			variance = variance + ((c2 - mean)*(c2 - mean));
		}
	
	if (c3 + sum != sum )
		{
			variance = variance + ((c3 - mean)*(c3 - mean));
		}
	
	if (c4 + sum != sum )
		{
			variance = variance + ((c4 - mean)*(c4 - mean));
		}
	
	if (c5 + sum != sum )
		{
			variance = variance + ((c5 - mean)*(c5 - mean));
		}
	
	if (d1 + sum != sum )
		{
			variance = variance + ((d1 - mean)*(d1 - mean));
		}
	
	if (d2 + sum != sum )
		{
			variance = variance + ((d2 - mean)*(d2 - mean));
		}
	
	if (d3 + sum != sum )
		{
			variance = variance + ((d3 - mean)*(d3 - mean));
		}
	
	if (d4 + sum != sum )
		{
			variance = variance + ((d4 - mean)*(d4 - mean));
		}
	
	if (d5 + sum != sum )
		{
			variance = variance + ((d5 - mean)*(d5 - mean));
		}
	
	if (e1 + sum != sum )
		{
			variance = variance + ((e1 - mean)*(e1 - mean));
		}
	
	if (e2 + sum != sum )
		{
			variance = variance + ((e2 - mean)*(e2 - mean));
		}
	
	if (e3 + sum != sum )
		{
			variance = variance + ((e3 - mean)*(e3 - mean));
		}
	
	if (e4 + sum != sum )
		{
			variance = variance + ((e4 - mean)*(e4 - mean));
		}
	if (e5 + sum != sum )
		{
			variance = variance + ((e5 - mean)*(e5 - mean));
		}
	if (f1 + sum != sum )
		{
			variance = variance + ((f1 - mean)*(f1 - mean));
		}
	if (f2 + sum != sum )
		{
			variance = variance + ((f2 - mean)*(f2 - mean));
		}
	if (f3 + sum != sum )
		{
			variance = variance + ((f3 - mean)*(f3 - mean));
		}
	if (f4 + sum != sum )
		{
			variance = variance + ((f4 - mean)*(f4 - mean));
		}
	if (f5 + sum != sum )
		{
			variance = variance + ((f5 - mean)*(f5 - mean));
		}
	if (g1 + sum != sum )
		{
			variance = variance + ((g1 - mean)*(g1 - mean));
		}
	if (g2 + sum != sum )
		{
			variance = variance + ((g2 - mean)*(g2 - mean));
		}
	if (g3 + sum != sum )
		{
			variance = variance + ((g3 - mean)*(g3 - mean));
		}
	if (g4 + sum != sum )
		{
			variance = variance + ((g4 - mean)*(g4 - mean));
		}
	if (g5 + sum != sum )
		{
			variance = variance + ((g5 - mean)*(g5 - mean));
		}
	if (h1 + sum != sum )
		{
			variance = variance + ((h1 - mean)*(h1 - mean));
		}
	if (h2 + sum != sum )
		{
			variance = variance + ((h2 - mean)*(h2 - mean));
		}
	if (h3 + sum != sum )
		{
			variance = variance + ((h3 - mean)*(h3 - mean));
		}
	if (h4 + sum != sum )
		{
			variance = variance + ((h4 - mean)*(h4 - mean));
		}
	if (h5 + sum != sum )
		{
			variance = variance + ((h5 - mean)*(h5 - mean));
		}
	
	variance = variance/(count-1);
	
	//Standard Deviation
	
	var s_d = Math.sqrt(variance);
	
/* 
    alert(mean);
   alert(median);
   alert(class1);
   alert(class7);
   alert(h1);
   alert(h6);
   alert(variance);
   alert(s_d);   */
 
   document.getElementById("mean").innerHTML = mean;
   document.getElementById("median").innerHTML = median;
   document.getElementById("variance").innerHTML = variance;
   document.getElementById("s_d").innerHTML = s_d;
}

</script>

<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<script>
//histogram
function graph(){
var trace = {
    x: arr,
    type: 'histogram',
  };
var data = [trace];
Plotly.newPlot('myDiv', data);
}
</script>

</head>
<body>
<div class="nav">
<img src="bingoo.jpg" style=" height: 55px;  border-top:3px solid #171974; border-bottom:1px solid #171974;border-left:30px solid #171974; 
    width: 75px;">
                <a class="button" href="help.php" style="float:right; border-radius: 8px;">HELP</a>
                <a class="button" href="about.php" style="float:right; border-radius: 8px;">ABOUT US</a>
                <a class="button" href="menu.php" style=" float:right; border-radius: 8px;" >MENU</a>
            </div>
                
            
                <div class="row">

                    <div class="column">
					<h1>Quantitative</h1>
                            <p>Insert Name Of Variable: </p>
                            <br>
                           <input type="text" id="name_variable" name="name_variable" >
                           <br>
                           <p>Insert Values: </p>
					
<form>

<div class="DIV" id="DIV1">
<input name="a1" id="a1" type="number">
<input name="a2" id="a2" type="number">
<input name="a3" id="a3" type="number">
<input name="a4" id="a4" type="number">
<input name="a5" id="a5" type="number">
<input name="b1" id="b1" type="number">
<input name="b2" id="b2" type="number">
<input name="b3" id="b3" type="number">
<input name="b4" id="b4" type="number">
<input name="b5" id="b5" type="number">
<br>
</div>
<div class="DIV" id="DIV3">
<input name="c1" id="c1" type="number">
<input name="c2" id="c2" type="number">
<input name="c3" id="c3" type="number">
<input name="c4" id="c4" type="number">
<input name="c5" id="c5" type="number">
<input name="d1" id="d1" type="number">
<input name="d2" id="d2" type="number">
<input name="d3" id="d3" type="number">
<input name="d4" id="d4" type="number">
<input name="d5" id="d5" type="number">
<br>
</div>
<div class="DIV" id="DIV5">
<input name="e1" id="e1" type="number">
<input name="e2" id="e2" type="number">
<input name="e3" id="e3" type="number">
<input name="e4" id="e4" type="number">
<input name="e5" id="e5" type="number">
<input name="f1" id="f1" type="number">
<input name="f2" id="f2" type="number">
<input name="f3" id="f3" type="number">
<input name="f4" id="f4" type="number">
<input name="f5" id="f5" type="number">
<br>
</div>
<div class="DIV" id="DIV7">
<input name="g1" id="g1" type="number">
<input name="g2" id="g2" type="number">
<input name="g3" id="g3" type="number">
<input name="g4" id="g4" type="number">
<input name="g5" id="g5" type="number">
<input name="h1" id="h1" type="number">
<input name="h2" id="h2" type="number">
<input name="h3" id="h3" type="number">
<input name="h4" id="h4" type="number">
<input name="h5" id="h5" type="number">
<br>
</div>

</form>
<button class="button" style ="text-align:center;border-radius: 8px;border: 5px solid #171974; padding: 5px 10px; font-size: 20px;" type=button name=more id=more onclick=" MyFunction()">Calculate</button>
</div>
<div class="column">


<br>
<br>
<div style ="text-align:center">
<p>Mean:				<p id="mean">0.00</p></p>
<p>median:				<p id="median">0.00</p> </p>
<p>Variance:			<p id="variance">0.00</p> </p>
<p>Standard Daviation:	<p id="s_d">0.00</p></p>
<div><button class="button" style ="text-align:center;border-radius: 8px;border: 5px solid #171974; padding: 5px 10px; font-size: 20px;" type=button name=more id=more onclick=" graph()">graph</button></div>
<div id="myDiv"></div>
</div>
</div>
</div>
            
            <div class="footer">        
                <p>bingoo</p>  
            </div>
</body>
</html>
